-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 18 jan. 2018 à 00:06
-- Version du serveur :  10.1.29-MariaDB
-- Version de PHP :  7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bac-a-sable`
--

-- --------------------------------------------------------

--
-- Structure de la table `configs`
--

CREATE TABLE `configs` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `ID` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `state` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`ID`, `name`, `content`, `created`, `state`, `type`, `slug`) VALUES
(1, 'Ma première page', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi quis bibendum massa, ut dictum orci. Mauris luctus ultrices varius. Nam auctor nibh vel dolor faucibus gravida. Nunc sed mauris in tortor elementum convallis at eu enim. Donec ut eros sed ligula lacinia lacinia a vel justo. Donec sit amet orci scelerisque lacus lobortis sollicitudin. Nam mollis a odio dapibus bibendum. Morbi sit amet urna et ipsum fringilla ornare vitae quis tellus. Nulla facilisi. Fusce sed finibus mi. Vestibulum vel turpis efficitur nisl elementum euismod vitae iaculis odio. Maecenas in ultrices tortor. Suspendisse et ante leo. Pellentesque enim ante, mollis id accumsan eu, cursus id lacus. Sed nec magna velit.</p>', '2017-12-22 01:00:00', 1, 'page', 'ma-premiere-page'),
(2, 'Page 2', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi quis bibendum massa, ut dictum orci. Mauris luctus ultrices varius. Nam auctor nibh vel dolor faucibus gravida. Nunc sed mauris in tortor elementum convallis at eu enim. Donec ut eros sed ligula lacinia lacinia a vel justo. Donec sit amet orci scelerisque lacus lobortis sollicitudin. Nam mollis a odio dapibus bibendum. Morbi sit amet urna et ipsum fringilla ornare vitae quis tellus. Nulla facilisi. Fusce sed finibus mi. Vestibulum vel turpis efficitur nisl elementum euismod vitae iaculis odio. Maecenas in ultrices tortor. Suspendisse et ante leo. Pellentesque enim ante, mollis id accumsan eu, cursus id lacus. Sed nec magna velit.</p>', '2017-12-27 19:55:00', 1, 'page', 'page-2'),
(3, 'Article premier du nom', '<p>Etiam in justo vulputate, mattis velit in, euismod purus. Integer scelerisque eros nec posuere luctus. Phasellus sed lacus pulvinar, porttitor nulla sit amet, vestibulum dolor. Morbi euismod ultrices tortor, sit amet molestie nunc dictum sed. Nulla facilisi. Sed vel pulvinar metus. Mauris auctor fermentum elit, eu suscipit libero dignissim ac. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec dui ex, imperdiet sit amet sem ac, dignissim feugiat felis. Cras tincidunt aliquam sapien a convallis. Fusce euismod sem odio, et vulputate ante bibendum in. Ut dignissim in quam vitae tincidunt. Ut rhoncus nulla quis ex cursus condimentum. Sed eget risus libero. Donec ut placerat elit, quis varius augue. In hac habitasse platea dictumst.</p>', '2017-12-27 19:58:00', 1, 'post', 'article-premier-du-nom'),
(4, 'Article 2', '<p>Etiam in justo vulputate, mattis velit in, euismod purus. Integer scelerisque eros nec posuere luctus. Phasellus sed lacus pulvinar, porttitor nulla sit amet, vestibulum dolor. Morbi euismod ultrices tortor, sit amet molestie nunc dictum sed. Nulla facilisi. Sed vel pulvinar metus. Mauris auctor fermentum elit, eu suscipit libero dignissim ac. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec dui ex, imperdiet sit amet sem ac, dignissim feugiat felis. Cras tincidunt aliquam sapien a convallis. Fusce euismod sem odio, et vulputate ante bibendum in. Ut dignissim in quam vitae tincidunt. Ut rhoncus nulla quis ex cursus condimentum. Sed eget risus libero. Donec ut placerat elit, quis varius augue. In hac habitasse platea dictumst.</p>', '2017-12-27 19:58:00', 1, 'post', 'article-2'),
(5, 'Article 3', '<p>Etiam in justo vulputate, mattis velit in, euismod purus. Integer scelerisque eros nec posuere luctus. Phasellus sed lacus pulvinar, porttitor nulla sit amet, vestibulum dolor. Morbi euismod ultrices tortor, sit amet molestie nunc dictum sed. Nulla facilisi. Sed vel pulvinar metus. Mauris auctor fermentum elit, eu suscipit libero dignissim ac. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec dui ex, imperdiet sit amet sem ac, dignissim feugiat felis. Cras tincidunt aliquam sapien a convallis. Fusce euismod sem odio, et vulputate ante bibendum in. Ut dignissim in quam vitae tincidunt. Ut rhoncus nulla quis ex cursus condimentum. Sed eget risus libero. Donec ut placerat elit, quis varius augue. In hac habitasse platea dictumst.</p>', '2017-12-27 19:58:00', 1, 'post', 'article-3');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `configs`
--
ALTER TABLE `configs`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `configs`
--
ALTER TABLE `configs`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
